import React from "react";

function BlankLayout({ children }) {
  return (
    <div>
      <div>{children}</div>
    </div>
  );
}

export default BlankLayout;
