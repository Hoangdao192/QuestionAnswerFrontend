import React from "react";

export function Home() {
    
    return (
        <div>Home</div>
    );
}
